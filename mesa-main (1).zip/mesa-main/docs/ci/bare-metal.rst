Bare-metal CI
=============

Bare-metal support is being removed from Mesa, and adding new devices is
no longer supported.

Please consider using one of the following alternatives:

- `CI-tron <https://gfx-ci.pages.freedesktop.org/ci-tron/>`__
- :doc:`LAVA`
