#!/usr/bin/env bash

DEBIAN_ARCH=armhf \
. .gitlab-ci/container/debian/test-base.sh
