#!/usr/bin/env bash

arch=i386

. .gitlab-ci/container/cross_build.sh
