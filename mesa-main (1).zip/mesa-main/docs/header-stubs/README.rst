Mock headers and types used only for building documentation, to avoid a
documentation dependency on generated headers, and to allow documentation of the
generated types.
