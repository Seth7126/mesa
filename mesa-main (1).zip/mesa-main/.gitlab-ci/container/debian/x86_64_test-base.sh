#!/usr/bin/env bash

DEBIAN_ARCH=amd64 \
. .gitlab-ci/container/debian/test-base.sh
